import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

def sendmail(to_email, url, price):
    mail_content = f"The price for the product {url} has dropped to ${price}. Buy now!"

    # The mail addresses and password
    sender_address = 'naaranivyshnavi@gmail.com'
    sender_pass = 'kkzsrbrnxhhhgpzk'
    #receiver_address = ['naaranivyshnavi@gmail.com']
    receiver_address=to_email
    host = 'smtp.gmail.com'
    port = 587

    # Setup the MIME
    message = MIMEMultipart()
    message['From'] = sender_address
    message['To'] = ", ".join(receiver_address)
    message['Subject'] = 'Price Drop Alert'  # The subject line

    # The body and the attachments for the mail
    message.attach(MIMEText(mail_content, 'plain'))

    # instance of MIMEBase and named as p
    p = MIMEBase('application', 'octet-stream')

    # attach the instance 'p' to instance 'msg'
    #message.attach(p)

    # Create SMTP session for sending the mail
    session = smtplib.SMTP(host, port)  # use gmail with port
    session.starttls()  # enable security
    session.login(sender_address, sender_pass)  # login with mail_id and password
    text = message.as_string()
    session.sendmail(sender_address, receiver_address, text)
    session.quit()
    print('Mail Sent')
    return 1