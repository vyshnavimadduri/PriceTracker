import os
import requests
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
from bs4 import BeautifulSoup
from flask import Flask, request, render_template, redirect, url_for,flash
from sendMail import sendmail
app = Flask(__name__)
app.secret_key = os.urandom(24)  # This generates a random secret key
# Store user data
user_data = []


# Function to check the price
def check_price():
    for data in user_data[:]:
        url = data['url']
        preferred_price = data['price']
        email = data['email']
        print (data)
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"}
        response = requests.get(url, headers=headers)
        print (response)
        #print (response.content)
        #print ("#############")
        soup = BeautifulSoup(response.content, 'html.parser')
        price_whole_span = soup.find('span', class_='a-price-whole')
        print (price_whole_span)
        if price_whole_span:
            whole_part = price_whole_span.text.strip()
            price = float(whole_part.replace(',', ''))
            print (price)
            if price <= preferred_price:
                print ("Current Price<=preferred price :).. send email")
                sendmail(email,url,price)
                user_data.remove(data)  # Remove the entry after sending the email
            else:
                print ("Current Price>preferred price.. :(")

# Create scheduler
scheduler = BackgroundScheduler()
scheduler.start()

# Add job to scheduler - check price every hour
scheduler.add_job(
    func=check_price,
    trigger=IntervalTrigger(seconds=10)
)


# Route for handling form submissions and displaying the form
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        url = request.form['url']
        price = float(request.form['price'])
        email = request.form['email']
        user_data.append({'url': url, 'price': price, 'email': email})
        flash('Your request has been accepted!')
        return redirect(url_for('index'))  # Redirect to clear form submission on refresh

    return render_template('index.html')


if __name__ == '__main__':
    app.run(debug=True)
